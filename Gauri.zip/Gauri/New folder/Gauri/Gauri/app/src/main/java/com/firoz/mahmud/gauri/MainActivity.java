package com.firoz.mahmud.gauri;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    long time=0;
    boolean msg=false;
    int count=0;
    Thread th;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.next_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,ColorBliend.class));
            }
        });
        findViewById(R.id.main_activity_tab_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(th==null) {
                    th = new Thread() {
                        @Override
                        public void run() {
                            int val = count;
                            do {
                                val = count;
                                try {
                                    sleep(500);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                            } while (val != count);
                            try {
                                play(count);
                            }catch (Exception e){}
                            count=0;
                            th=null;
                        }
                    };
                    th.start();
                }
                count++;


            }
        });
    }
    public void play(int count){
        switch (count) {
            case 6:
            MediaPlayer playr = MediaPlayer.create(MainActivity.this, R.raw.a1);
            playr.start();
            break;
            case 5:
                MediaPlayer playr1 = MediaPlayer.create(MainActivity.this, R.raw.a2);
                playr1.start();
                break;
            case 3:
                MediaPlayer playr2 = MediaPlayer.create(MainActivity.this, R.raw.a3);
                playr2.start();
                break;
            case 4:
                MediaPlayer playr3 = MediaPlayer.create(MainActivity.this, R.raw.a4);
                playr3.start();
                break;
            case 2:
                MediaPlayer playr4 = MediaPlayer.create(MainActivity.this, R.raw.a5);
                playr4.start();
                break;
            case 1:
                MediaPlayer playr5 = MediaPlayer.create(MainActivity.this, R.raw.a6);
                playr5.start();
                break;
        }
    }
}