package com.firoz.mahmud.gauri;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.io.File;
import java.io.IOException;

public class ColorBliend extends AppCompatActivity {
ImageView iv;
File file;
Bitmap bit=null;
TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_color_bliend);
        iv=findViewById(R.id.color_image);
        file=new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES),"image.jpg");
        if(file.exists()){
            file.delete();
        }
            try {
                file.createNewFile();
            } catch (IOException e) {

            }



        tv=findViewById(R.id.color_textview);
        iv.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent me) {
                if(bit==null)return true;
                if(me.getAction()==MotionEvent.ACTION_UP){
                    float x=me.getX();
                    float y=me.getY();
                    int h=iv.getHeight();
                    int w=iv.getWidth();
                    double posx=(x/w)*bit.getWidth();
                    double posy=(y/h)*bit.getHeight();
                    int col=bit.getPixel((int)posx,(int)posy);
                    int green=col-Color.GREEN;
                    green=green<0?green*-1:green;
                    int red=col-Color.RED;
                    red=red<0?red*-1:red;
                    int blue=col-Color.BLUE;
                    blue=blue<0?blue*-1:blue;
                    if(green<4800000){
                        tv.setText("GREEN");
                    }
                    else if(red<4800000){
                        tv.setText("RED");
                    }else if(blue<4800000){
                        tv.setText("BLUE");
                    }else{
                        tv.setText("Unknown");
                    }


                }
                return true;
            }
        });

        findViewById(R.id.capture_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                Uri photoURI = FileProvider.getUriForFile(ColorBliend.this,"com.firoz.mahmud.gauri",file);
                in.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                startActivityForResult(Intent.createChooser(in,"Take photo via:"),101);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==101&&resultCode== Activity.RESULT_OK)
        {
            bit= BitmapFactory.decodeFile(file.getAbsolutePath());
            iv.setImageBitmap(bit);
        }
    }
}