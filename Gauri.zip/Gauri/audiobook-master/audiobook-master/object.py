import mediapipe as mp
import cv2
import pyttsx3
from playsound import playsound as pl



mp_ob=mp.solutions.objectron
speaker = pyttsx3.init()
ob=mp_ob.Objectron(static_image_mode=False,max_num_objects=2,min_detection_confidence=0.5,min_tracking_confidence=0.7,model_name='Chair')
dr=mp.solutions.drawing_utils
vp=cv2.VideoCapture(0)
while True:
    suc,image=vp.read()
    img=image
    image=cv2.cvtColor(image,cv2.COLOR_BGR2RGB)


    res=ob.process(image)
    if res.detected_objects:
        for obj in res.detected_objects:
            dr.draw_landmarks(img,obj.landmarks_2d,mp_ob.BOX_CONNECTIONS)
            x=obj.landmarks_2d.landmark[0].x
            y=obj.landmarks_2d.landmark[0].y
            x*=10
            y*=10
            data=""
            try:
                if x<5 and y<5:
                    pl("voice/bameupor.mp3")
                elif x<5 and y>=5:
                    pl("voice/bamenic.mp3")
                elif x>5 and y<5:
                    pl("voice/daneupor.mp3")
                elif x>5 and y>=5:
                    pl("voice/dnenic.mp3")
                elif x==5 and y<5:
                    pl("voice/majheupre.mp3")
                elif x==5 and y==5:
                    pl("voice/majhe.mp3")
                elif x==5 and y>5:
                    pl("voice/majhenic.mp3")
            except:
                print('failed to play');
    cv2.imshow("Shuvoda",img)
    cv2.waitKey(1)